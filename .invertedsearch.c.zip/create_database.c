#include "invereted.h"
/*
Name        : Chandu
Date        :  
Description :
sample I/P  :
sample O/P  :
 */

int create_database(slist *head,mnode *data[])
{
	printf("P");
	int count=0;
	for(int i=0;i<26;i++)
	{
		if(data[i]==0)
			count++;
	}
	if(count!=26)
	{
		printf("database is not empty\n");
		return FAILURE;
	}


	slist *temp=head;
	while(temp!=NULL)
	{
		FILE *fp=fopen(temp->filename,"r");
		char word[50];
		while(fscanf(fp,"%s",word)!=-1)
		{
			int index=tolower(word[0])%97;
			if(data[index]==0)
			{
				mnode *mainnode=malloc(sizeof(mnode));
				if(mainnode==NULL)
					return FAILURE;
				snode *subnode=malloc(sizeof(snode));
				if(subnode==NULL)
				{
					return FAILURE;
				}
				mainnode->filecount=1;
				strcpy(mainnode->word,word);
				mainnode->mainlink=NULL;
				strcpy((subnode->filename),(temp->filename));
				subnode->wordcount=1;
				subnode->slink=NULL;
				mainnode->slink=subnode;
				data[index]=mainnode;
			}
			else
			{
				mnode *prev1=NULL;
				mnode *temp1=data[index];
				while(temp1 != NULL)
				{
					if(!(strcmp((temp1->word),word)))
					{
						break;
					}
					prev1=temp1;
					temp1=temp1->mainlink;
				}
				//mnode *temp1;
				if(temp1==NULL)
				{
					mnode *mainnode=malloc(sizeof(mnode));
					if(mainnode==NULL)
					{
						return FAILURE;
					}
					snode *subnode=malloc(sizeof(snode));
					if(subnode==NULL)
						return FAILURE;
					mainnode->filecount=1;
					strcpy(mainnode->word,word);
					mainnode->mainlink=NULL;
					strcpy((subnode->filename),(temp->filename));
					subnode->wordcount=1;
					subnode->slink=NULL;
					mainnode->slink=subnode;
					prev1->mainlink=mainnode;
				}
				if(temp1!=NULL)
				{
					int flag = 0;
					if(!(strcmp((temp1->slink->filename),(temp->filename))))
					{
						temp1->slink->wordcount==((temp1->slink->wordcount)+1);
					}
					else
					{
						snode *temp2=temp1->slink;
						snode *prev=NULL;
						while(temp2!=NULL)
						{
							if(!(strcmp((temp2->filename),(temp->filename))))
							{
								temp2->wordcount=((temp2->wordcount)+1);
								flag=1;
								break;
							}
							prev=temp2;
							temp2=temp2->slink;
						}
						if(flag==0)
						{
							snode *subnode=malloc(sizeof(snode));
							if(subnode==NULL)
								return FAILURE;
							subnode->wordcount=1;
							subnode->slink=NULL;
							strcpy((subnode->filename),(temp->filename));
							prev1->slink=subnode;
							temp1->filecount=((temp1->filecount)+1);
						}

					}
				}
			}	
		}
		temp=temp->link;
	}
}



