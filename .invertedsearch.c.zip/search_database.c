#include "invereted.h"
/*
Name        : Chandu
Date        : 
Description :
sample I/P  :
sample O/P  :
*/
int search_database(mnode *data[])
{
	char word[50];
	scanf("%s",word);
	int index=tolower(word[0]%97);
	mnode *temp=data[index];
	if(data[index]==0)
		return FAILURE;
	while(temp!=NULL)
	{
		if(!(strcmp((temp->word),word)))
			break;
		while(temp!=NULL)
		{
			if(!(strcmp((temp->word),word)))
				break;
			temp=temp->mainlink;
		}
		printf("word %s is present in %d files\n",word,temp->filecount);
		snode *temp1=temp->slink;
		while(temp1!=NULL)
		{
			printf("%s->%d\n",temp1->filename,temp1->wordcount);
			temp1=temp1->slink;
		}
		if(temp==NULL)
			printf("ERROR:Word not present in database");
	}

	//return 0;
}


