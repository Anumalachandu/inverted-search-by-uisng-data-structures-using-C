#ifndef invereted_h
#define invereted_h

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#define SUCCESS 1
#define FAILURE 0


typedef struct mainode
{
	struct mainode *mainlink;
	struct subnode *slink;
	int filecount;

	char word[26];
}mnode;

typedef struct subnode
{
	int wordcount;
	char filename[30];
	struct subnode *slink;
}snode;
typedef struct node
{
	char filename[29];
	struct node *link;
}slist;

int not_duplicate(char *str,slist **head);
int search_database(mnode *data[]);
int save_database(slist *head,mnode *data[]);
int open_file(char *str);
int file_not_empty(char *str);
int insert_last(char *str,slist **head);
int update_database(slist *head,mnode *data[]);
int valid_file(char *str);
int create_database(slist *head,mnode *data[]);
int display_database(slist *head,mnode *data[]);
int main_code(slist *head);
#endif
