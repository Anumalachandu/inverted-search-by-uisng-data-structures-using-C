#include"invereted.h"
/*
Name        : Chandu
Date        : 
Description :
sample I/P  :
sample O/P  :
*/
int display_database(slist *head,mnode *data[])
{
	printf("%-6s %-20s %-15s %-12s\n","[index]","word","file(s)","word count");
	for(int i=0;i<26;i++)
	{
		mnode *mainnode=data[i];
		while(mainnode != NULL)
		{
			printf("[%5d] %-10s %d file/s:",i,mainnode->word,mainnode->filecount);
			snode *subnode=mainnode->slink;
			while(subnode!=NULL)
			{
				printf(" file: %-15s %d",subnode->filename,subnode->wordcount);
				subnode=subnode->slink;
			}
			printf("\n");
			mainnode=mainnode->mainlink;
			
		}
	}

	return SUCCESS;
}


