#include"invereted.h"

/*
Name        : Chandu
Date        : 
Description :
sample I/P  :
sample O/P  :
 */
int save_database(slist *head,mnode *data[])
{
	int count=0;
	for(int i=0;i<26;i++)
	{
		if(data[i]==0)
		{
			count++;
		}
	}
	if(count==26)
	{
		printf("database is empty");
	}
	else
	{
		char str[20];
		printf("enter the filename with extention.txt:");
		scanf("%s",str);
		FILE *fptr=fopen(str,"w");
		if(fptr==NULL)
		{
			printf("file does not exist");
			return FAILURE;
		}
		char name[20]="#";
		for(int i=0;i<26;i++)
		{
			if(data[i]!=NULL)
			{
				mnode *temp=data[i];
				while(temp!=NULL)
				{
					fprintf(fptr,"%s;",name);
					fprintf(fptr,"%d;",i);
					fprintf(fptr,"%s;",temp->word);
					fprintf(fptr,"%d",temp->filecount);
					fprintf(fptr,"%s;",(temp->slink->filename));
					fprintf(fptr,"%d;",temp->slink->wordcount);
					snode *temp1=temp1->slink;
					while(temp1!=NULL)
					{
						fprintf(fptr,";%s",temp1->filename);
						fprintf(fptr,";%d",temp1->wordcount);
						temp1=temp1->slink;
					}
					if(temp1==NULL)
					{
						fprintf(fptr,"%s\n",name);
					}
					temp=temp->mainlink;
				}
			}
		}
		fclose(fptr);
	}
}


