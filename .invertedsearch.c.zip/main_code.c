#include "invereted.h"
int main_code(slist *head)
{
	mnode *data[26];
	for(int i=0;i<26;i++)
		data[i] = 0;
	while(1)
	{
		printf("1. Create Database\n2. Display Database\n3. Search Database\n4. Save Database\n5. Update database\n6. Exit\nEnter your choice : ");
		int n=0;
		scanf("%d",&n);
		switch(n)
		{
			case 1:
				{
					printf("P");
					if(create_database(head,data) == SUCCESS)
					{
						printf("Successful : Creation of DATABASE for files\n");
					}
					else
					{
						printf("ERROR : Database is not created\n");
					}
					break;
				}
			case 2:
				{
					if(display_database(head,data) == SUCCESS)
					{
						printf("INFO : Dispaly Database success\n");
					}
				}
				break;
			case 3:
				{
					if(search_database(data) == SUCCESS)
					{
						printf("INFO : Search Database is Success\n");
					}
					else
					{
						printf("INFO : Given word is not present\n");
					}
				}
				break;
			case 4:
				{
					if(save_database(head,data) == SUCCESS)
					{
						printf("Database is saved\n");
					}
				}
				break;
			case 5:
				{
					if(update_database(head,data) == SUCCESS)
					{
						printf("INFO : Update database is Success\n");
					}
				}
				break;
			case 6:
				return SUCCESS;
				break;
		}
	}


	return 0;
}
