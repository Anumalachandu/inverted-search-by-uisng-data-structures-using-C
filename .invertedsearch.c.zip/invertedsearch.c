#include "invereted.h"

/*
Name        : Chandu
Date        : 
Description :
sample I/P  :
sample O/P  :
 */
int main(int argc,char *argv[])
{
	slist *head=NULL;

	int i=1;
	if(argc>1)
	{
		while(i<argc)
		{
			if(not_duplicate(argv[i],&head)==SUCCESS)
			{
				if(open_file(argv[i])==SUCCESS)
				{
					if(file_not_empty(argv[i])==SUCCESS)
					{
						if(insert_last(argv[i],&head)==SUCCESS)
						{
							printf("info: validation is done\n");
						}
					}
					else
					{
						printf("%s,INFO:file is empty\n",argv[i]);
					}
				}
			}
			else
			{
				printf("%s INFO:Duplicate file\n",argv[i]);
			}
			i++;
		}
	}
	else
	{
		printf("%s INFO:give sufficient file name\n",argv[i]);
	}
if(main_code(head) == SUCCESS)
{
	printf("INFO : success");
}
	return 1;
}


/*		if(head==NULL)
		{
		printf("INFo:list is empty\n");
		}
		else
		{
		while(head)
		{
		printf("%s->",head->filename);
		head=head->filename;
		}
		printf("NULL\n");
		}
		if(main_code(head)==SUCCESS)
		{
		printf("INFO:Done\n");
		}
		else
		{
		printf("INFO:error in maincode");
		}
		return 0;
		}

		}

		int duplica(char *str,slist **heead)
		{
		slist argv[30];
		FILE *fptr=fopen(str,"r");
		if(fptr==NULL)
		{
		printf("file not exist");
		return 0;
		}
		fseek(fptr,0,SEEK_END);
		if(ftell(fptr)==0)

		{
		printf("empty");
		return 0;
		}
		if(*head==NULL)
		{
		slist *new=malloc(sizeof(slist));
		strcpy(new->filename,str);
		new->link=NULL;
 *head=new;
 }
 slist *temp=*head;
 else
 {
//slist *temp=*head;
while(temp->link!=NULL)
{
if(strcmp(temp->filename,str)==0)
{
printf("duplicate file");
return 0;
}
temp=temp->link;
}
}
if(strcmp(temp->filename,str)==0)
{
printf("duplicate file");
return 0;
}
slist *new=malloc(sizeof(slist));
strcpy(new->filename,str);
new->link=NULL;
temp->link=new;
}

*/

int not_duplicate(char *str,slist **head)
{
	if(*head==NULL)
		return SUCCESS;
	slist *temp=*head;
	while(temp!=NULL)
	{
		if(!(strcmp(str,temp->filename)))
			return 0;
		temp=temp->link;
	}
	return SUCCESS;
}
int open_file(char *str)
{
	FILE *fptr=fopen(str,"r");
	if(fptr==NULL)
	{
		perror("fopen");
		fprintf(stderr,"Error: unable to open %s\n",str);
		return 0;
	}
	return 1;
}
int file_not_empty(char *str)
{
	FILE *fptr=fopen(str,"r");
	fseek(fptr,0,SEEK_END);
	int size=ftell(fptr);
	if(size==0)
		return 0;
	return 1;
}
int insert_last(char *str,slist **head)
{
	slist *new=malloc(sizeof(slist));
	
	if(new==NULL)
	{
		return 0;
	}
	strcpy(new->filename,str);
	new->link=NULL;
	if(*head==NULL)
	{
		*head=new;
		return SUCCESS;
	}
	slist *current=*head;
		
		while(current->link!=NULL)
		{
			current=current->link;
		}
		current->link=new;
		return 1;
}








